const formulaire = document.getElementById("formulaire")
const inputAge = document.getElementById("age")

function valider(event) {
    event.preventDefault()
    const age = inputAge.value
    if (age > 11) {
        window.location = "secret.html";
    } else {
        window.location = "refus.html";
    }
}

formulaire.addEventListener("submit", valider)
