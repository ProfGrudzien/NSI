from bottle import get, post, request, run, template, static_file, redirect

@get('/style.css')
def get_style() :
    return static_file('style.css', root='')

@get('/')
def get_index():
    return template('index')

@get('/formulaire')
def get_formulaire():
    return template('formulaire')

@post('/formulaire')
def post_formulaire():
    return template('secret')

run(host='localhost', port=8080, debug=True)
