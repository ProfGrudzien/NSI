const couleurs = ["noir", "rouge", "jaune", "blanc", "bleu"];

function handleClick(event) {
    const div = event.target;
    if (div.classList[0] == "sep") {
        changeBordure(div);
    } else if (couleurs.indexOf(div.className) > -1) {
        changeCouleur(div);
    }
}
    
function changeCouleur(div) {
    const oldIndex = couleurs.indexOf(div.className);
    const newIndex = (oldIndex + 1) % 5;
    div.className = couleurs[newIndex];
}

function changeBordure(div) {

}

document.addEventListener("click", handleClick);
