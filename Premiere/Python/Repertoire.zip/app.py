import sys
sys.path.append("./modules")

from bottle import get, post, request, response, run, template, static_file, redirect
from gestion_repertoire import *

repertoire = creer_repertoire()

@get('/style.css')
def server_static() :
    return static_file('style.css', root='')

@get('/')
def index():
    parametres = {
        'erreur_ajout': '',
        'nom_ajout': '',
        'numero_ajout': '',
    }
    return template('index', **parametres)

@get('/contact/<nom>')
def contact(nom):
    numero = recherche_par_nom(repertoire, nom)
    if numero is None :
        parametres = {
            'titre': 'Erreur !',
            'erreur': 'Impossible de trouver le contact «' + nom + '».',
            'message': '',
        }
        return template('message', **parametres)
    else :
        parametres = {
            'nom': nom,
            'numero': numero,
        }
        return template('contact', **parametres)

@post('/recherche_nom')
def post_recherche_nom():
    nom = request.forms.nom
    redirect('/contact/' + nom)

@post('/recherche_numero')
def post_recherche_numero():
    numero = request.forms.numero
    nom = recherche_par_numero(repertoire, numero)
    if nom is None :
        parametres = {
            'titre': 'Erreur !',
            'erreur': 'Aucun contact ne correspond au numéro «' + numero + '»',
            'message': '',
        }
        return template('message', **parametres)
    else :
        redirect('/contact/' + nom)

@post('/ajouter')
def post_ajouter():
    nom = request.forms.nom
    numero = request.forms.numero
    if ajouter_contact(repertoire, nom, numero) :
        parametres = {
            'titre': 'Succés !',
            'erreur': '',
            'message': 'Le contact «' + nom + '» a bien été créé.',
        }
        return template('message', **parametres)
    else :
        parametres = {
            'erreur_ajout': 'Ajout impossible : un autre contact porte ce nom.',
            'nom_ajout': nom,
            'numero_ajout': numero,
        }
        return template('index', **parametres)

@get('/supprimer/<nom>')
def supprimer(nom):
    if supprimer_contact(repertoire, nom) :
        parametres = {
            'titre': 'Succés !',
            'erreur': '',
            'message': 'Le nouveau contact a été créé.',
        }
    else :
        parametres = {
            'titre': 'Erreur !',
            'erreur': 'Le contact a retirer est introuvable.',
            'message': '',
        }
    return template('message', **parametres)

@get('/modifier/<nom>')
def modifier(nom):
    numero = recherche_par_nom(repertoire, nom)
    if numero is None :
        parametres = {
            'titre': 'Erreur !',
            'erreur': 'Le contact a modifier est introuvable.',
            'message': '',
        }
        return template('message', **parametres)
    else :
        parametres = {
            'nom': nom,
            'nouveau_nom': nom,
            'nouveau_numero': numero,
            'erreur': '',
        }
        return template('modifier', **parametres)

@post('/modifier')
def post_modifier():
    nom = request.forms.nom
    nouveau_nom = request.forms.nouveau_nom
    nouveau_numero = request.forms.nouveau_numero
    if modifier_contact(repertoire, nom, nouveau_nom, nouveau_numero) :
        parametres = {
            'titre': 'Succés !',
            'erreur': '',
            'message': 'Le contact a bien été modifié.',
        }
        return template('message', **parametres)
    elif nom == nouveau_nom :
        parametres = {
            'titre': 'Erreur !',
            'erreur': 'Le contact a modifier est introuvable.',
            'message': '',
        }
        return template('message', **parametres)
    else :
        parametres = {
            'nom': nom,
            'nouveau_nom': nouveau_nom,
            'nouveau_numero': nouveau_numero,
            'erreur': 'Modification impossible : un autre contact porte déjà ce nom.',
        }
        return template('modifier', **parametres)

run(host='localhost', port=8080, debug=True)
